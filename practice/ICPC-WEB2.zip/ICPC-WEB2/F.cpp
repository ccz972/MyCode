#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;

const int N = 1e6 + 10;
__int128 sum[N];

map<int, int> fa1, fa2;

inline void solve(){
    fa1.clear(), fa2.clear();
    int k, x, y; cin >> k >>  x >> y;
    sum[1] = 1;
    for(int i = 2; sum[i - 1] <= max(x, y); i++) sum[i] = sum[i - 1] * (k + 1);
    int pos = 0;
    for(int i = 1; sum[i - 1] <= max(x, y); i++){
        if(sum[i] >= x){
            pos = i - 1;
            break;
        }
    }
    int dep1 = 0, dep2 = 0;
    int nfa = x;
    while(nfa != 1){
        int now = nfa;
        fa1[now] = ((now - sum[pos]) + (k - 1)) / k;
        // cout << "dep => " << dep1 << " " << fa1[now] << endl;
        nfa = fa1[now];
        while(sum[pos] >= nfa) pos--;

        dep1++;
    }
    pos = 0;
    for(int i = 1; sum[i - 1] <= max(x, y); i++){
        if(sum[i] >= y){
            pos = i - 1;
            break;
        }
    }
    nfa = y;
    while(nfa != 1){
        int now = nfa;
        fa2[now] = ((now - sum[pos]) + (k - 1)) / k;
        // cout << "dep => " << dep1 << " " << fa[now] << endl;
        nfa = fa2[now];
        while(sum[pos] >= nfa) pos--;
        // cout << "@@@" << pos << endl;
        dep2++;
    }

    if(dep1 < dep2) while(dep1 < dep2) y = fa2[y], dep2--;
    if(dep1 > dep2) while(dep1 > dep2) x = fa1[x], dep1--;
    if(x == y) {
        cout << x << endl;
        return;
    }
    while(fa1[x] != fa2[y]) x = fa1[x], y = fa2[y];

    cout << fa1[x] << endl;
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);

    int t = 1; cin >> t;
    while(t--) solve();
    return 0;
}