#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
#define pii pair<int,int> 
using namespace std;
const int mod =998244353;
const int N = 2e6 + 10;

string s;
int x, a, b, p;
int prec[N],prep[N],prei[N];
int precp[N],prepc[N],preic[N],preicp[N];
int precpc[N];
int preicpc[N];
int askl[N],askr[N];
int ans,sum;
inline void solve(){
    int n, q; cin >> n >> q >> s;
    cin >> x >> a >>b >>p;
    s=" "+s;
    for(int i=1;i<=n;i++){
        prei[i]=prei[i-1]+(s[i]=='I');
        prec[i]=prec[i-1]+(s[i]=='C');
        prep[i]=prep[i-1]+(s[i]=='P');
        preic[i]=(preic[i-1]+prei[i-1]*(s[i]=='C'))%mod;
        prepc[i]=(prepc[i-1]+prep[i-1]*(s[i]=='C'))%mod;
        precp[i]=(precp[i-1]+prec[i-1]*(s[i]=='P'))%mod;
        preicp[i]=(preicp[i-1]+preic[i-1]*(s[i]=='P'))%mod;
        preicpc[i]=(preicpc[i-1]+preicp[i-1]*(s[i]=='C'))%mod;
        precpc[i]=(precpc[i-1]+precp[i-1]*(s[i]=='C'))%mod;
        //cout << "@@@" << endl;
    }
    for(int i = 1; i <= q; i++){
        x=(x*a+b)%p;
        askl[i]=x%n;
    }
    for(int i = 1; i <= q; i++){
        x=(x*a+b)%p;
        askr[i]=x%n;
        if(askl[i]>askr[i])swap(askl[i],askr[i]);
        askl[i]++;askr[i]++;
    }
    for(int i=1;i<=q;i++){
        int l=askl[i],r=askr[i];
        int lrc=prec[r]-prec[l-1],lrpc=(prepc[r]-prepc[l-1]-prep[l-1]*lrc%mod+mod+mod)%mod;
        ans=(preicpc[r]-preicpc[l-1]-preicp[l-1]*lrc%mod+mod+mod)%mod;
        ans=(ans-preic[l-1]*lrpc%mod+mod)%mod;
        int lrcpc=(precpc[r]-precpc[l-1]+mod-precp[l-1]*lrc%mod+mod-prec[l-1]*lrpc%mod+mod)%mod;
        ans=(ans-prei[l-1]*lrcpc%mod+mod)%mod;
        (sum+=ans)%=mod;
        //cout<<ans<<endl;
    }
    cout<<sum;
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1; //cin >> t;
    while(t--) solve();
    return 0;
}