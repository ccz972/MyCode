#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;

const int N = 1e3 + 10;
int a[N][N], b[N][N];
int tot, pr[N], loop[N];
inline void solve(){
    int n; cin>>n;
    int m=min(n,100ll);
    for(int i=1;i<=m;i++)
    {
        for(int j=1;j<=i;j++)
        {
            cin>>a[i][j];
        }
    }
    int q; cin>>q;
    while(q--)
    {
        int x; cin>>x;
        if(n<=100)
        {
            int ans=0;
            for(int i=1;i<=n;i++)
            {
                ans=(ans*10+a[n][i])%x;
            }
            cout<<ans<<"\n";
        }else 
        {
        int k=loop[x];
        int ans=0;
        //cout<<k<<"\n";
        for(int i=1;i<=k;i++)
        {
            int dd=n-i+1;
            dd=(dd-1+k)%k+1;
            //cout<<i<<' '<<dd<<"\n";
            //cout<<i<<' '<<a[k][i]<<' '<<b[x][dd]<<"\n";
            (ans+=a[k][i]*b[x][dd]%x)%=x;
        }
        cout<<ans<<"\n";
        }
    }
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1; 
    for(int i=3;i<=100;i++)
    {
        if(i==5) continue;
        int fg=0;
        for(int j=2;j*j<=i;j++)
        {
            if(i%j==0) 
            {
                fg=1;
                break;
            }
        }
        if(!fg) pr[++tot]=i;
    }
    for(int i=1;i<=tot;i++)
    {
        int cnt=1,base=10%pr[i];
        b[pr[i]][cnt]=1;
        while(base!=1)
        {
            cnt++;
            b[pr[i]][cnt]=base;
            base=base*10%pr[i];
        }
        loop[pr[i]]=cnt;
    }
    //for(int i=1;i<=tot;i++) cout<<pr[i]<<' '<<loop[pr[i]]<<"\n";
    cin >> t;
    while(t--) solve();
    return 0;
}