#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;
const int mod = 998244353;
const int N = 1e5 + 10;
int qpow(int x,int y=mod-2,int res=1){
    for(;y;y>>=1,(x*=x)%=mod) if(y&1)(res*=x)%=mod;
    return res;
}
int p2=qpow(2,mod-2),p3=qpow(3,mod-2);
struct node 
{
    int x,y;
}po[N];
//map <pair<int,int>, int > mp;
int n;
int mp[300][300][5];
int ansl,ansr;
inline void solve(){
    // int n; cin>>n;
    // for(int i=1;i<=n;i++)
    // {
    //     int p; cin>>p>>po[i].x>>po[i].y;
    //     mp[{po[i].x,po[i].y}]=p;
    // }
    // int ans1=0, ans2=0;
    // for(int i=1;i<=n;i++)
    // {
    //     int x=po[i].x, y=po[i].y;
    //     if(mp[{x,y}]==1)
    //     {
    //         int l=x-2
    //     }
    //     else 
    //     {

    //     }
    // }
    cin>>n;
    for(int i=1;i<=n;i++){
        int op,x,y;cin>>op>>x>>y;
        x+=102;y+=102;
        if(op==1){
            for(int j=0;j<4;j++){
                mp[x][y][j]=1;
                mp[x-1][y][j]=1;
                mp[x][y-1][j]=1;
                mp[x-1][y-1][j]=1;
            }
        }
        else{
            mp[x][y][2]=1;mp[x][y][3]=1;
            mp[x][y-1][0]=1;mp[x][y-1][3]=1;
            mp[x-1][y][2]=1;mp[x-1][y][1]=1;
            mp[x-1][y-1][0]=1;mp[x-1][y-1][1]=1;
        }
    }
    for(int i=1;i<=205;i++){
        for(int j=1;j<=205;j++){
            int res=0;
            for(int k=0;k<4;k++){
                res+=mp[i][j][k];
            }
            if(mp[i][j][0]){
                if(mp[i][j+1][2]==0){
                    ansl++;
                }
            }
            if(mp[i][j][1]){
                if(mp[i+1][j][3]==0){
                    ansl++;
                }
            }
            if(mp[i][j][2]){
                if(mp[i][j-1][0]==0){
                    ansl++;
                }
            }
            if(mp[i][j][3]){
                if(mp[i-1][j][1]==0){
                    ansl++;
                }
            }
            if(res==3){
                (ansr+=p3)%=mod;
            }
            else if(res==2){
                (ansr+=p2)%=mod;
            }
        }
    }
    cout<<ansl<<" "<<ansr<<endl;
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1; 
    //cin >> t;
    while(t--) solve();
    return 0;
}