#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;

const int N = 1e6 + 10;
int n,k;
inline void solve(){
    cin>>n;
    k=min(n,100);
    for(int i=1;i<=k;i++){
        for(int j=1;j<=k;k++)
    }
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1;  cin >> t;
    while(t--) solve();
    return 0;
}