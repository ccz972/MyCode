#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;

const int N = 2e5 + 10, MOD = 1e9 + 7;

inline void solve(){
    int n, k; cin >> n >> k;
    int sum = 0, cur = k;
    for(int i = 2; i <= n; i++){
        int fnd = 2;
        for(int j = 2; j < cur; j++){
            if(__gcd(j, cur) == 1){
                fnd = j;
                break;
            }
        }
        
        if(fnd == 2){
            int left = (n - i + 1);
            if(left & 1) sum += 5 * (left / 2) + 2;
            else sum += 5 * (left / 2);
            break;
        } else{
            sum += fnd;
        }
        cur = fnd;
        
    }
    cout << sum + k << endl;
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    cout << fixed << setprecision(12);
    int t = 1; // cin >> t;
    while(t--) solve();
    return 0;
}