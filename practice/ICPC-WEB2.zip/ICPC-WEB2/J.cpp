#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
#define pii pair<int,int>
using namespace std;

const int N = 2e5 + 10, MOD = 1e9 + 7;
int a[N];
map<pii,int>mp;
inline void solve(){
    int n = 0, k = 0; cin >> n;
    for(int i = 1; i <= n; i++) cin >> a[i];
    int szl=0,szr=0;
    for(int i=1;i<=n;i++){
        if(a[i]>a[i-1]){
            szl++;
        }
        else break;
    }
    for(int i=n;i;i--){
        if(a[i]>a[i+1]){
            szr++;
        }
        else break;
    }
    int cnt=0;
    for(int l=1,r=n;l<=szl&&(n-r+1)<=szr;){
        //cout<<l<<" "<<r<<endl;
        if(a[l]==a[r]){
            if((szl-l+1)%2||(szr-(n-r+1))%2){
                cnt++;
            }
            break;
        }
        if(a[l]<a[r]){
            if((szr-(n-r))%2){
                cnt++;
                break;
            }
            else{
                l++;
                cnt++;
            }
        }
        else if(a[l]>a[r]){
            if((szl-l+1)%2){
                cnt++;
                break;
            }
            else{
                r--;
                cnt++;
            }
        }
    }
    //cout<<cnt<<endl;
    if(cnt%2){
        cout<<"Alice";
    }
    else{
        cout<<"Bob";
    }
    

}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    cout << fixed << setprecision(12);
    int t = 1; // cin >> t;
    while(t--) solve();
    return 0;
}