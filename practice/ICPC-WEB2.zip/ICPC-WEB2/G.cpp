#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
#define pii pair<int,int>
using namespace std;

const int N = 1e5 + 10, mod = 1000000007;
int qpow(int x,int y=mod-2,int res=1){
    for(;y;y>>=1,(x*=x)%=mod) if(y&1)(res*=x)%=mod;
    return res;
}
int jie[1000005],invjie[1000005];
int C(int n,int m){
    return jie[n]*invjie[m]%mod*invjie[n-m]%mod;
}
pii b[1000005];
struct node{
    int l,r;
    bool operator<(const node &t)const {
        return l<t.l||l==t.l&&r>t.r;
    }
}a[1000005];
int fa[1000005];
int n,m,fg;
vector<int>p[1000005];
int dp[1000005],l[1000005];
void main_init(int n){
    jie[0]=1;
    for(int i=1;i<=n;i++){
        jie[i]=jie[i-1]*i%mod;
    }
    invjie[n]=qpow(jie[n]);
    for(int i=n-1;~i;i--){
        invjie[i]=invjie[i+1]*(i+1)%mod;
    }
}
void dfs(int u){
    int res=1;
    l[u]=a[u].r-a[u].l+1;
    int len=l[u];
    for(auto v:p[u]){
        dfs(v);
        (res*=dp[v])%=mod;
        len-=l[v];
    }
    len+=p[u].size();
    dp[u]=jie[len]*res%mod;
    //cout<<u<<"!!"<<dp[u]<<endl;
}
inline void solve(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>a[i].l>>a[i].r;
        if(a[i].l==1&&a[i].r==n)fg=1;
        if(a[i].l==a[i].r){i--;m--;}
        //b[i].first=l;b[i].second=r;
    }
    if(!fg){
        m++;
        a[m].l=1;a[m].r=n;
    }
    sort(a+1,a+1+m);
    
    for(int i=2,nowfa=1;i<=m;i++){
        while(a[nowfa].r<a[i].l){
            nowfa=fa[nowfa];
        }
        fa[i]=nowfa;
        p[fa[i]].push_back(i);
        //cout<<i<<" "<<fa[i]<<"!@#\n";
        nowfa=i;
    }
    dfs(1);
    // for(int i=1;i<=m;i++){
    //     cout<<p[i].size()<<"???\n";
    // }
    // for(int i=1;i<=m;i++){
    //     cout<<i<<" "<<fa[i]<<endl;
    // }
    cout<<dp[1]<<endl;
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1; //cin >> t;
    main_init(1000000);
    while(t--) solve();
    return 0;
}