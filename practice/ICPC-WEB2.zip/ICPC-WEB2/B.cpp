#include <bits/stdc++.h>
#pragma gcc optimize("O2")
#pragma g++ optimize("O2")
#define int long long
#define endl '\n'
using namespace std;

const int N = 1e6 + 10;
int a[N];
int d[1005],sum[20005],sum1[200005];
int dp[105][105];
//表示前i个数合并了j次的最大值
int val[105][105];
inline void solve(){
    int n = 0; cin >> n;
    for(int i =1;i<=n;i++){
        cin>>a[i];
    }
    int k=n-1;
    for(int i=1;i<n;i++){
        d[i]=a[i+1]-a[i];
        sum[i]=sum[i-1]+d[i];
        sum1[i]=sum1[i-1]+d[i]*d[i];
    }
    for(int l=1;l<=k;l++){
        for(int r=l;r<=k;r++){
            val[l][r]=(sum[r]-sum[l-1])*(sum[r]-sum[l-1]);
        }
    }
    for(int i=1;i<=k;i++){
        dp[i][0]=sum1[i];
        dp[i][i-1]=val[1][i];
        for(int j=1;j<i;j++){
            for(int len=0,t=i;len<=j;len++,t--){
                //cout<<"???\n";
                dp[i][j]=max(dp[i][j],dp[t-1][j-len]+val[t][i]);
            }
        }
    }
    // for(int i=1;i<=k;i++){
    //     for(int j=0;j<=k;j++){
    //         cout<<dp[i][j]<<" \n"[j==k];
    //     }
    // }
    for(int i=1;i<=n;i++){
        if(i*2>=k){
            cout<<dp[n-1][k-1]<<endl;
        }
        else{
            cout<<dp[n-1][i*2]<<endl;
        }
    }

    
}

signed main(){
    ios_base::sync_with_stdio(false), cin.tie(0);
    int t = 1; // cin >> t;
    while(t--) solve();
    return 0;
}